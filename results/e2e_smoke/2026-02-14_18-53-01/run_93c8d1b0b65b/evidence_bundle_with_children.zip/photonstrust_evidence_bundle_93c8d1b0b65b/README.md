# PhotonTrust Evidence Bundle

- generated_at: 2026-02-14T17:53:03.455401+00:00
- root_run_id: 93c8d1b0b65b
- include_children: true

This bundle contains run manifests + declared artifacts for offline review.
Integrity metadata is recorded in bundle_manifest.json (sha256 per file).
