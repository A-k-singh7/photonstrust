# PhotonTrust Evidence Bundle

- generated_at: 2026-02-14T17:53:03.866854+00:00
- root_run_id: d903dbbcc3c4
- include_children: true

This bundle contains run manifests + declared artifacts for offline review.
Integrity metadata is recorded in bundle_manifest.json (sha256 per file).
