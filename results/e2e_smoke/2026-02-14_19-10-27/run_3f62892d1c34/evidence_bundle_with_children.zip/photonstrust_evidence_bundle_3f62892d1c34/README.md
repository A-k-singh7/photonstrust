# PhotonTrust Evidence Bundle

- generated_at: 2026-02-14T18:10:32.094822+00:00
- root_run_id: 3f62892d1c34
- include_children: true

This bundle contains run manifests + declared artifacts for offline review.
Integrity metadata is recorded in bundle_manifest.json (sha256 per file).
