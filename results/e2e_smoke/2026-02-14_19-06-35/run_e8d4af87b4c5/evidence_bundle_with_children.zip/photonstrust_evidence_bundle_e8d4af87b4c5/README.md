# PhotonTrust Evidence Bundle

- generated_at: 2026-02-14T18:06:40.372893+00:00
- root_run_id: e8d4af87b4c5
- include_children: true

This bundle contains run manifests + declared artifacts for offline review.
Integrity metadata is recorded in bundle_manifest.json (sha256 per file).
